# SaturnScore

## Summary ##

Python package that computes the Saturn coefficient of a matrix to assess the quality of its UMAP dimensionality reduction.


## Contacts ##

The `SaturnScore` package was developed by [Davide Chicco](https://www.DavideChicco.it). Questions should be
addressed to davidechicco(AT)davidechicco.it
